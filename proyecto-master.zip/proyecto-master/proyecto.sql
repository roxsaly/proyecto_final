﻿-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-07-2019 a las 18:33:54
-- Versión del servidor: 10.3.16-MariaDB
-- Versión de PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad_deportiva`
--

CREATE TABLE `actividad_deportiva` (
  `futbol` varchar(30) NOT NULL,
  `tenis` varchar(30) NOT NULL,
  `tae_kwondo` varchar(30) NOT NULL,
  `basquet` varchar(30) NOT NULL,
  `handball` varchar(30) NOT NULL,
  `voleyball` varchar(30) NOT NULL,
  `natacion` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_alumno`
--

CREATE TABLE `datos_alumno` (
  `id_alumno` int(11) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `dni` int(8) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `edad` int(3) NOT NULL,
  `sexo` varchar(8) NOT NULL,
  `contacto_casa` int(15) NOT NULL,
  `contacto_celular` int(15) NOT NULL,
  `email` text NOT NULL,
  `peso` int(3) NOT NULL,
  `estatura` int(3) NOT NULL,
  `imagen_alumno` varchar(50) NOT NULL,
  `imagen_dni_alumno` varchar(50) NOT NULL,
  `status` int(2) NOT NULL,
  `provincia` varchar(20) NOT NULL,
  `localidad` varchar(20) NOT NULL,
  `calle` varchar(20) NOT NULL,
  `numero_calle` int(5) NOT NULL,
  `departamento` varchar(5) NOT NULL,
  `cobertura medica` varchar(30) NOT NULL,
  `num_afiliado` int(30) NOT NULL,
  `pers_contacto` varchar(30) NOT NULL,
  `tlf_pers_contacto` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_responsable`
--

CREATE TABLE `datos_responsable` (
  `id_responsable` int(11) NOT NULL,
  `id_alumno` int(11) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `dni` int(8) NOT NULL,
  `parentesco` varchar(15) NOT NULL,
  `tlf_1` int(15) NOT NULL,
  `tlf_2` int(15) NOT NULL,
  `viven_juntos` int(3) NOT NULL,
  `direccion` varchar(60) NOT NULL,
  `email` text NOT NULL,
  `imagen_dni` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `enfermedades`
--

CREATE TABLE `enfermedades` (
  `id_alumno` int(11) NOT NULL,
  `fractura` varchar(30) NOT NULL,
  `esguinces` varchar(30) NOT NULL,
  `hernias` varchar(30) NOT NULL,
  `p_conocimiento` varchar(30) NOT NULL,
  `e_muscular` varchar(30) NOT NULL,
  `asma` varchar(30) NOT NULL,
  `hip_arterial` varchar(30) NOT NULL,
  `convulsiones` varchar(30) NOT NULL,
  `neumonia` varchar(30) NOT NULL,
  `varicela` varchar(30) NOT NULL,
  `s_cardiaco` varchar(30) NOT NULL,
  `anemia` varchar(30) NOT NULL,
  `saramp_rubeola` varchar(30) NOT NULL,
  `hepatitis` varchar(30) NOT NULL,
  `a_cardiacas` varchar(30) NOT NULL,
  `interv_quirurgica` varchar(30) NOT NULL,
  `imagen_apto_medico` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarios`
--

CREATE TABLE `horarios` (
  `id` int(11) NOT NULL,
  `horario` time(6) NOT NULL,
  `id_turno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `horarios`
--

INSERT INTO `horarios` (`id`, `horario`, `id_turno`) VALUES
(3, '10:00:00.000000', 1),
(4, '13:00:00.000000', 1),
(5, '13:00:00.000000', 2),
(6, '14:00:00.000000', 2),
(7, '18:00:00.000000', 3),
(8, '19:00:00.000000', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `instructor`
--

CREATE TABLE `instructor` (
  `id_instructor` int(4) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `instructor`
--

INSERT INTO `instructor` (`id_instructor`, `nombre`, `apellido`) VALUES
(1, 'Marina', 'Perez'),
(2, 'Claudio', 'Marquez'),
(3, 'Rogelio', 'Vargas'),
(4, 'Pablo', 'Sanchez');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turno`
--

CREATE TABLE `turno` (
  `id` int(11) NOT NULL,
  `nombre_turno` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `turno`
--

INSERT INTO `turno` (`id`, `nombre_turno`) VALUES
(1, 'Diurno'),
(2, 'Tarde'),
(3, 'Noche');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubic_geog_localidad`
--

CREATE TABLE `ubic_geog_localidad` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubic_geog_prov`
--

CREATE TABLE `ubic_geog_prov` (
  `id_provincia` int(11) NOT NULL,
  `nombre_provincia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `usr_id` int(11) NOT NULL,
  `usr_nombre` varchar(30) CHARACTER SET utf8 NOT NULL,
  `usr_pasword` varchar(10) CHARACTER SET utf8 NOT NULL,
  `usr_email` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `datos_alumno`
--
ALTER TABLE `datos_alumno`
  ADD PRIMARY KEY (`id_alumno`);

--
-- Indices de la tabla `datos_responsable`
--
ALTER TABLE `datos_responsable`
  ADD PRIMARY KEY (`id_responsable`),
  ADD KEY `id_alumno` (`id_alumno`);

--
-- Indices de la tabla `enfermedades`
--
ALTER TABLE `enfermedades`
  ADD KEY `id_alumno` (`id_alumno`);

--
-- Indices de la tabla `horarios`
--
ALTER TABLE `horarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_turno` (`id_turno`);

--
-- Indices de la tabla `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`id_instructor`);

--
-- Indices de la tabla `turno`
--
ALTER TABLE `turno`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ubic_geog_localidad`
--
ALTER TABLE `ubic_geog_localidad`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ubic_geog_prov`
--
ALTER TABLE `ubic_geog_prov`
  ADD PRIMARY KEY (`id_provincia`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`usr_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `datos_alumno`
--
ALTER TABLE `datos_alumno`
  MODIFY `id_alumno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `datos_responsable`
--
ALTER TABLE `datos_responsable`
  MODIFY `id_responsable` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `horarios`
--
ALTER TABLE `horarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `instructor`
--
ALTER TABLE `instructor`
  MODIFY `id_instructor` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `turno`
--
ALTER TABLE `turno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ubic_geog_localidad`
--
ALTER TABLE `ubic_geog_localidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ubic_geog_prov`
--
ALTER TABLE `ubic_geog_prov`
  MODIFY `id_provincia` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `usr_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `datos_alumno`
--
ALTER TABLE `datos_alumno`
  ADD CONSTRAINT `datos_alumno_ibfk_1` FOREIGN KEY (`id_alumno`) REFERENCES `datos_responsable` (`id_alumno`);

--
-- Filtros para la tabla `enfermedades`
--
ALTER TABLE `enfermedades`
  ADD CONSTRAINT `enfermedades_ibfk_1` FOREIGN KEY (`id_alumno`) REFERENCES `datos_alumno` (`id_alumno`);

--
-- Filtros para la tabla `horarios`
--
ALTER TABLE `horarios`
  ADD CONSTRAINT `horarios_ibfk_1` FOREIGN KEY (`id_turno`) REFERENCES `turno` (`id`);

--
-- Filtros para la tabla `ubic_geog_localidad`
--
ALTER TABLE `ubic_geog_localidad`
  ADD CONSTRAINT `ubic_geog_localidad_ibfk_1` FOREIGN KEY (`id`) REFERENCES `ubic_geog_prov` (`id_provincia`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

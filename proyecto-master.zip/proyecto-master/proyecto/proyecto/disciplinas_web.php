<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

	<header>
	     <?php
		include("header.php");
		?> 
	</header>

	<footer>
		<?php
		include("footer.php");
		?>
	</footer>

	
</body>
</html>
<?php include "conexion.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <head>
        <?php include("header.php");?>
    </head>
    <body>
       <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a>
                   
                   
                </div>
            </div>
            <!-- /navbar-inner -->
        </div><br />

            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div class="content">
                            <?php
			if(isset($_POST['input'])){
				$nombre	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['nombre'], ENT_QUOTES)));
				$apellido  = mysqli_real_escape_string($mysqli,(strip_tags($_POST['apellido'], ENT_QUOTES)));
				$horario 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_horarios'], ENT_QUOTES)));
		
				$insert = mysqli_query($mysqli, "INSERT INTO instructor(id_instructor, nombre, apellido, id_horarios)
															VALUES(NULL,'$nombre', '$apellido', '$horario')") or die(mysqli_error());
						if($insert){
							echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Bien hecho, los datos han sido agregados correctamente.</div>';
						}else{
							echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error, no se pudo registrar los datos.</div>';
						}
				
			}
			?>
            
            <blockquote>
            Agregar Instructor
            </blockquote>
                         <form name="form1" id="form1" class="form-horizontal row-fluid" action="instructor_registro.php" method="POST" >
										<div class="control-group">
											<label class="control-label" for="nombre">Nombre</label>
											<div class="controls">
												<input type="text" name="nombre" id="nombre" placeholder="Nombres del Instructor" class="form-control span8 tip" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="apellido">Apellido</label>
											<div class="controls">
												<input type="text" name="apellido" id="apellido" placeholder="apellido del instructor" class="form-control span8 tip" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="id_horarios">Horario</label>
											<div class="controls">
												<input name="id_horarios" id="id_horarios" class="form-control span8 tip" type="number" placeholder="Horario"  required />
											</div>
										</div>

                                      

										<div class="control-group">
											<div class="controls">
												<button type="submit" name="input" id="input" class="btn btn-sm btn-primary">Registrar</button>
                                               <a href="instructores.php" class="btn btn-sm btn-danger">Cancelar</a>
											</div>
										</div>
									</form>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        
        <!--/.wrapper--><br />
        <div class="footer span-12">
            <div class="container">
              <center> <b class="copyright">footer </b></center>
            </div>
        </div>

        <script src="js/bootstrap.min.js" type="text/javascript"></script>
      
    </body>
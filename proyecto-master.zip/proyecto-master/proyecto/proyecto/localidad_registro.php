<?php include "conexion.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <head>
        <?php include("header.php");?>
    </head>
    <body>
       <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a>
                   
                   
                </div>
            </div>
            <!-- /navbar-inner -->
        </div><br />

            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div class="content">
                            <?php
			if(isset($_POST['input'])){
				$nombre_localidad	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['nombre_localidad'], ENT_QUOTES)));
				$id_provincia  	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_provincia'], ENT_QUOTES)));
		
				$insert = mysqli_query($mysqli, "INSERT INTO ubic_localidad(id_localidad, nombre_localidad, id_provincia)
															VALUES(NULL,'$nombre_localidad', '$id_provincia')") or die(mysqli_error());
						if($insert){
							echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Bien hecho, los datos han sido agregados correctamente.</div>';
						}else{
							echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error, no se pudo registrar los datos.</div>';
						}
				
			}
			?>
            
            <blockquote>
            Agregar Horario
            </blockquote>
                         <form name="form1" id="form1" class="form-horizontal row-fluid" action="localidad_registro.php" method="POST" >
										<div class="control-group">
											<label class="control-label" for="nombre_localidad">Localidad</label>
											<div class="controls">
												<input type="text" name="nombre_localidad" id="nombre_localidad" placeholder="Registro de la Localidad" class="form-control span8 tip" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="id_provincia">Id Provincia</label>
											<div class="controls">
												<input type="text" name="id_provincia" id="id_provincia" placeholder="Registro de Provincia" class="form-control span8 tip" required>
											</div>
										</div>
                                      

										<div class="control-group">
											<div class="controls">
												<button type="submit" name="input" id="input" class="btn btn-sm btn-primary">Registrar</button>
                                               <a href="localidad.php" class="btn btn-sm btn-danger">Cancelar</a>
											</div>
										</div>
									</form>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        
        <!--/.wrapper--><br />
        <div class="footer span-12">
            <div class="container">
              <center> <b class="copyright">footer </b></center>
            </div>
        </div>

        <script src="js/bootstrap.min.js" type="text/javascript"></script>
      
    </body>
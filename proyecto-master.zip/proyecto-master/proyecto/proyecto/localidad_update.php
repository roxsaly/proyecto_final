<?php
include "conexion.php";
if(isset($_POST['update'])){
				$id_localidad = intval($_POST['id_localidad']);
				$nombre_localidad	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['nombre_localidad'], ENT_QUOTES)));
				$id_provincia  	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_provincia'], ENT_QUOTES)));
               
				
				$update = mysqli_query($mysqli, "UPDATE horarios 
											   SET nombre_localidad='$nombre_localidad', 
											   	   id_provincia='$id_provincia', 
											   WHERE id_localidad='$id_localidad'") or die(mysqli_error());
				if($update){
					echo "<script>alert('Los datos han sido actualizados!'); window.location = 'horarios.php'</script>";
				}else{
					echo "<script>alert('Error, no se pudo actualizar los datos'); window.location = 'horarios.php'</script>";
				}
			}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Polideportivo los coquitos</title>
</head>
<body>
	<footer class="text-muted">
		<div class="container"></div>
		<p class="float-right">Sitio Web desarrolado por RoxsyH con © Bootstrap</p>
		
	</footer>



</body>
</html>
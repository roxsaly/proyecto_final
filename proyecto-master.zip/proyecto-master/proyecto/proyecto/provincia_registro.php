<?php include "conexion.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <head>
        <?php include("header.php");?>
    </head>
    <body>
       <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a>
                   
                   
                </div>
            </div>
            <!-- /navbar-inner -->
        </div><br />

            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div class="content">
                            <?php
			if(isset($_POST['input'])){
				$nombre_provincia	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['nombre_provincia'], ENT_QUOTES)));
		
				$insert = mysqli_query($mysqli, "INSERT INTO ubic_prov(id_provincia, nombre_provincia)
															VALUES(NULL,'$nombre_provincia')") or die(mysqli_error());
						if($insert){
							echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Bien hecho, los datos han sido agregados correctamente.</div>';
						}else{
							echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error, no se pudo registrar los datos.</div>';
						}
				
			}
			?>
            
            <blockquote>
            Agregar Provincia
            </blockquote>
                         <form name="form1" id="form1" class="form-horizontal row-fluid" action="horarios_registro.php" method="POST" >
										<div class="control-group">
											<label class="control-label" for="nombre_provincia">Nombre Provincia</label>
											<div class="controls">
												<input type="text" name="nombre_provincia" id="nombre_provincia" placeholder="Registro de la Provincia" class="form-control span8 tip" required>
											</div>
										</div>

										<div class="control-group">
											<div class="controls">
												<button type="submit" name="input" id="input" class="btn btn-sm btn-primary">Registrar</button>
                                               <a href="provincia.php" class="btn btn-sm btn-danger">Cancelar</a>
											</div>
										</div>
									</form>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        
        <!--/.wrapper--><br />
        <div class="footer span-12">
            <div class="container">
              <center> <b class="copyright">footer </b></center>
            </div>
        </div>

        <script src="js/bootstrap.min.js" type="text/javascript"></script>
      
    </body>
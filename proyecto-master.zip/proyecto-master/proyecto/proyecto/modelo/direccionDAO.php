<?php

    include_once PATH_HELPERS . '/database_helper.php';

    function buscarProvincia( $provincia ){
        $conexion = getConexion();

        $consulta = "SELECT * " . 
                  "FROM ubic_geog_prov " . 
                  "WHERE id_provincia = " . $nombre_provincia;

        $resultado = $conexion->query( $consulta );

        return $resultado;
    }

    
    function eliminarProvincia( $provincia){

        $conexion = getConexion();

        $sql = "DELETE FROM ubic_geog_prov " .         
               " WHERE id_provincia = " . $nombre_provincia;

        $resultado = $conexion->query( $sql );

    }

    function agregarProvincia( $provincia ){

        $conexion = getConexion();

        $sql = "INSERT INTO ubic_geog_prov " . 
                    "(nombre_provincia)" 
                        . " VALUES ('" 
                        . $id_provincia["nombre"] . "', '"

                     . ")";

        $conexion->query( $sql );

    }

    function modificarProvincia( $provincia ){

        $conexion = getConexion();

        $sql = "UPDATE ubic_geog_prov SET " . 
                    "nombre_provincia= \"" . $nombre["nombre"];
        
        $sql .= " WHERE id_provincia = " . $provincia["id"];


        $conexion->query( $sql );



    }
?>
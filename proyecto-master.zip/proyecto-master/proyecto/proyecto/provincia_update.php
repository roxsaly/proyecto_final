<?php
include "conexion.php";
if(isset($_POST['update'])){
				$id_provincia = intval($_POST['id_provincia']);
				$nombre_provincia	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['nombre_provincia'], ENT_QUOTES)));
               
				
				$update = mysqli_query($mysqli, "UPDATE ubic_prov 
											   SET nombre_provincia='$nombre_provincia', 
											   WHERE id_provincia='$id_provincia'") or die(mysqli_error());
				if($update){
					echo "<script>alert('Los datos han sido actualizados!'); window.location = 'provincia.php'</script>";
				}else{
					echo "<script>alert('Error, no se pudo actualizar los datos'); window.location = 'provincia.php'</script>";
				}
			}
  ?>
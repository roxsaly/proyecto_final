<?php include "conexion.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <head>
        <?php include("header.php");?>
    </head>
    <body>
       <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a>
                   
                   
                </div>
            </div>
            <!-- /navbar-inner -->
        </div><br />

            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div class="content">
                            <?php
			if(isset($_POST['input'])){
				$horario	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['horario'], ENT_QUOTES)));
				$id_turno  	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_turno'], ENT_QUOTES)));
		
				$insert = mysqli_query($mysqli, "INSERT INTO horarios(id_instructor, horario, id_turno)
															VALUES(NULL,'$horario', '$id_turno')") or die(mysqli_error());
						if($insert){
							echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Bien hecho, los datos han sido agregados correctamente.</div>';
						}else{
							echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error, no se pudo registrar los datos.</div>';
						}
				
			}
			?>
            
            <blockquote>
            Agregar Horario
            </blockquote>
                         <form name="form1" id="form1" class="form-horizontal row-fluid" action="horarios_registro.php" method="POST" >
										<div class="control-group">
											<label class="control-label" for="horario">Horario</label>
											<div class="controls">
												<input type="text" name="horario" id="horario" placeholder="Registro del Horario" class="form-control span8 tip" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="id_turno">Id Turno</label>
											<div class="controls">
												<input type="text" name="id_turno" id="id_turno" placeholder="Registro del Turno" class="form-control span8 tip" required>
											</div>
										</div>
                                      

										<div class="control-group">
											<div class="controls">
												<button type="submit" name="input" id="input" class="btn btn-sm btn-primary">Registrar</button>
                                               <a href="horarios.php" class="btn btn-sm btn-danger">Cancelar</a>
											</div>
										</div>
									</form>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        
        <!--/.wrapper--><br />
        <div class="footer span-12">
            <div class="container">
              <center> <b class="copyright">footer </b></center>
            </div>
        </div>

        <script src="js/bootstrap.min.js" type="text/javascript"></script>
      
    </body>
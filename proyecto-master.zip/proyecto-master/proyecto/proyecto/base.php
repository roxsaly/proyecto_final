<!DOCTYPE html>
<?php
	require('conexion.php');
	
	session_start();
	
	if(isset($_SESSION["id_usuario"])){
		header("Location: ingreso.php");
	}
	
	if(!empty($_POST))
	{
		$usuario = mysqli_real_escape_string($mysqli,$_POST['usuario']);
		$password = mysqli_real_escape_string($mysqli,$_POST['password']);
		$error = '';
		
		//$sha1_pass = sha1($password);
		
		$sql = "SELECT usr_id FROM usuario WHERE usr_nombre = '$usuario' AND usr_pasword = '$password' ";
		$result=$mysqli->query($sql);
		$rows = $result->num_rows;
		
		if($rows > 0) {
			$row = $result->fetch_assoc();
			$_SESSION['id_usuario'] = $row['usr_id'];
			
			header("location: ingreso.php");
			} else {?>
				<script>alert('El nombre o contraseña son incorrectos');</script>
				<?php
			//$error = "El nombre o contraseña son incorrectos";
		}
	}
?>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Polideportivo los coquitos</title>

</head>
<body>

	<header>
	     <?php
		include("header.php");
		?> 
	</header>

<!-- Carrusel -->

<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">

<div class="col-md-12">
  <div class="carousel-inner">

	    <div class="carousel-item active">
	        <img src="img/poli1.png" class="d-block w-100" alt="Futbol">
	    </div>
	    <div class="carousel-item">
	      <img src="img/poli2.png" class="d-block w-100" alt="Basquet">
	    </div>
  </div>

 </div> 
</div>
  

	<article>
		<br>
		<br>

	<div class="row">
      <div class="col-lg-1" >
      </div>

      <div class="col-lg-2" >
       
 <!--botones de enlace y formulario-->      
			<div class="btn-group-vertical"  role="group" aria-label="Grupo de botones vertical">
				
				<a href="disciplinas_web.php" class="btn btn-info" role="button">Disciplinas</a>
				<a href="formulario_registro.php" class="btn btn-info" role="button">Inscripción año 2019<img src="img/new.png" width="20%"></a>
		
			</div>
	
      </div>
      <div class="col-lg-5" >
       
		<div class="card">	
			<div class="card-img-top">
 				 <img src="img\deporte2.png" width="450" class="card-rounded " alt="Disciplinas">
			</div>
		</div>

      </div>
 		<div class="col-lg-3" >
       		<div class="card">	
			<div class="card-body">
				<h4 class="card-title">POLIDEPORTIVOS LOS COQUITOS</h4>
				<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae non repudiandae ea eos architecto amet, cumque sed, quisquam corporis magnam, laudantium maiores obcaecati iusto velit aperiam, vero eveniet placeat. Dolorem!</p>
				<p>
				<a class="btn" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ver detalles "</font></font></a>
			</p>
			</div>
		</div>
      </div>

 	   <div class="col-lg-1"  >
     
      </div>
<a data-toggle="modal" data-target="#exampleModal" class="nav-link" href="#">Ingresá</a>
	</div>

	</article>

	<footer>
		<?php
		include("footer.php");
		?>
	</footer>

		<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Ingresar a Polideportivo</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">

			<div class="row justify-content-center">
				<div class="col-md-8">
					<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" >  

						<input type="hidden" name="m" value="login">

						<div class="form-group">
							 
							<label for="user_name">Nombre de usuario</label>

							<input type="text" class="form-control" name="usuario" id="user_name"  />
						</div>

						<div class="form-group">
							 
							<label for="password">Contraseña</label>

							<input type="password" class="form-control" name="password" id="password"  />
						</div>

						<button type="submit" class="btn btn-primary">
							Ingresar
						</button>

					</form>
				</div>
			</div>

	      </div>
	      
	    </div>
	  </div>
	</div>
	
</body>
</html>
<?php
include "conexion.php";
if(isset($_POST['update'])){
				$id_horarios = intval($_POST['id_horarios']);
				$horario	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['horario'], ENT_QUOTES)));
				$id_turno  	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_turno'], ENT_QUOTES)));
               
				
				$update = mysqli_query($mysqli, "UPDATE horarios 
											   SET horario='$horario', 
											   	   id_turno='$id_turno', 
											   WHERE id_horarios='$id_horarios'") or die(mysqli_error());
				if($update){
					echo "<script>alert('Los datos han sido actualizados!'); window.location = 'horarios.php'</script>";
				}else{
					echo "<script>alert('Error, no se pudo actualizar los datos'); window.location = 'horarios.php'</script>";
				}
			}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="Container">
		<h1><div class="py-5 text-center">Datos de Madre, Padre o Responsable</div></h1>
	</div>

<form class="needs-validation" novalidate>
		
<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="Nombres">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" id="Nombres" placeholder="Nombres" >
			<div class="invalid-feedback">
				Valide el nombre es requerido
			</div>
		</div>		

		<div class="form-group col-md-4">
			<label for="Apellidos">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" id="apellido" placeholder="Apellidos">
			<div class="invalid-feedback">
				Valide el apellido es requerido
			</div>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>

			<div class="form-group col-md-4">
      		<label for="Document">
 			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>	     			
      		</label>
      		<input type="number" class="form-control" id="dni" placeholder="DNI">
      		<div class="invalid-feedback">
      			Valide el DNI es requerido
      		</div>
    	</div>

    	<div class="form-group col-md-4">
			<select class="custom-select">
  			<option selected>Parentesco</option>
  			<option value="1">Madre</option>
 			<option value="2">Padre</option>
 			<option value="3">Responsable</option>
			</select>
			<div class="invalid-feedback">
      			Valide el Parentesco es requerido
   			</div>
		</div>

    <div class="form-group col-md-2"></div>
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="Telefono">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" id="Telefono1" placeholder="Telefono de Contacto" >
		</div>		

		<div class="form-group col-md-4">
			<label for="inputEmail3">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" id="inputEmail3" placeholder="Correo electrónico">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>

		<div class="form-group col-md-4">
		 <legend class="col-form-label col-sm-6">Vive con el alumno</legend>
      		
          	<input class="form-check-input col-md-1" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
          	<label class="form-check-label col-md-4" for="gridRadios1">Si</label>
          	<input class="form-check-input col-md-1" type="radio" name="gridRadios" id="gridRadios2" value="option2">
         	<label class="form-check-label col-md-6" for="gridRadios2">No</label>
		</div>

		<div class="form-group col-md-4">
			<label for="Dirección">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" id="Dirección" placeholder="Dirección en caso de que no viva con el alumno">
			<div class="invalid-feedback">
				Valide la dirección es requerido
			</div>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

	
</body>
</html>
<?php
//servidor, usuario de base de datos, contraseña del usuario, nombre de base de datos

	$mysqli=new mysqli("localhost","root","","proyecto"); 
	
	if(!$mysqli->set_charset("utf8")) {
		echo 'Conexion Fallida : ', mysqli_connect_error();
		exit();

	}
	/*define( 'HOST' , 'localhost' );
	define( 'USER' , 'root' );
	define( 'PASSWORD' , '' );
	define( 'BD' , 'proyecto' );

	function getConexion(){
		
		$conexion = new mysqli( HOST, USER, PASSWORD, BD );

        $conexion->set_charset('utf8');

		return $conexion;*/
?>
<?php
include "conexion.php";
if(isset($_POST['update'])){
				$id_instructor = intval($_POST['id_instructor']);
				$nombre	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['nombre'], ENT_QUOTES)));
				$apellido  	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['apellido'], ENT_QUOTES)));
				$horario 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_horarios'], ENT_QUOTES)));
               
				
				$update = mysqli_query($mysqli, "UPDATE instructor 
											   SET nombre='$nombre', 
											   	   apellido='$apellido', 
											   	   id_horarios='$horario'
											   WHERE id_instructor='$id_instructor'") or die(mysqli_error());
				if($update){
					echo "<script>alert('Los datos han sido actualizados!'); window.location = 'instructores.php'</script>";
				}else{
					echo "<script>alert('Error, no se pudo actualizar los datos'); window.location = 'instructores.php'</script>";
				}
			}
  ?>
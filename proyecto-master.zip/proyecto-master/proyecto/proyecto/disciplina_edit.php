<?php include "conexion.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <head>
      <?php include("header.php");?>
    </head>
    <body>
       <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a>
                   
                   
                </div>
            </div>
            <!-- /navbar-inner -->
        </div><br />

            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div class="content">
                            <?php
           $id_actividad = intval($_GET['id_actividad']);
			$sql = mysqli_query($mysqli, "SELECT * FROM actividad_deportiva WHERE id_actividad='$id_actividad'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: disciplina_deportiva.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			?>
            
            <blockquote>
            Actualizar Actividad Deportiva
            </blockquote>
                         <form name="form1" id="form1" class="form-horizontal row-fluid" action=disciplina_update.php" method="POST" >
										<div class="control-group">
											<label class="control-label" for="basicinput">ID</label>
											<div class="controls">
												<input type="text" name="id_actividad" id="id_actividad" value="<?php echo $row['id_actividad']; ?>" placeholder="Tidak perlu di isi" class="form-control span8 tip" readonly="readonly">
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Nombre de Actividad</label>
											<div class="controls">
												<input type="text" name="descripcion" id="descripcion" value="<?php echo $row['descripcion']; ?>" placeholder="Incluir Nombre de la Actividad" class="form-control span8 tip" required>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Instructor</label>
											<div class="controls">
												<input type="text" name="id_instructor" id="id_instructor" value="<?php echo $row['id_instructor']; ?>" placeholder="Incluir Instructor" class="form-control span8 tip" required>
											</div>
										</div>
								

										<div class="control-group">
											<div class="controls">
												<input type="submit" name="update" id="update" value="Actualizar" class="btn btn-sm btn-primary"/>
                                               <a href="disciplina_deportiva.php" class="btn btn-sm btn-danger">Cancelar</a>
											</div>
										</div>
									</form>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        
        <!--/.wrapper--><br />
        <div class="footer span-12">
            <div class="container">
              <center> <b>  Inicio Sistema Web Polideportivo </b></center>
            </div>
        </div>

        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        


      
    </body>
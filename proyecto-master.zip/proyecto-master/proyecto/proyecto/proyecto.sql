-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-07-2019 a las 04:53:28
-- Versión del servidor: 10.1.30-MariaDB
-- Versión de PHP: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad_deportiva`
--

CREATE TABLE `actividad_deportiva` (
  `id_actividad` int(16) NOT NULL,
  `descripcion` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `id_instructor` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `actividad_deportiva`
--

INSERT INTO `actividad_deportiva` (`id_actividad`, `descripcion`, `id_instructor`) VALUES
(3, 'Fútbol', 6),
(4, 'Voleyball', 5),
(5, 'Baloncesto', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno_enfermedad`
--

CREATE TABLE `alumno_enfermedad` (
  `id_alumno` int(20) NOT NULL,
  `id_enfermedad` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_alumno`
--

CREATE TABLE `datos_alumno` (
  `id_alumno` int(20) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `dni` int(8) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `edad` int(3) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `contacto_casa` int(15) NOT NULL,
  `contacto_celular` int(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `peso` int(3) NOT NULL,
  `estatura` int(3) NOT NULL,
  `imagen_alumno` varchar(50) NOT NULL,
  `imagen_dni_alumno` varchar(50) NOT NULL,
  `id_provincia` int(11) NOT NULL,
  `id_localidad` int(11) NOT NULL,
  `calle` varchar(20) NOT NULL,
  `numero_calle` int(5) NOT NULL,
  `departamento` varchar(5) NOT NULL,
  `cobertura_medica` varchar(30) NOT NULL,
  `num_afiliado` int(30) NOT NULL,
  `pers_contacto` varchar(30) NOT NULL,
  `tlf_pers_contacto` int(15) NOT NULL,
  `id_actividad` int(16) NOT NULL,
  `id_instructor` int(16) NOT NULL,
  `id_horario` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_responsable`
--

CREATE TABLE `datos_responsable` (
  `id_responsable` int(11) NOT NULL,
  `id_alumno` int(11) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `dni` int(8) NOT NULL,
  `parentesco` varchar(15) NOT NULL,
  `tlf_1` int(15) NOT NULL,
  `tlf_2` int(15) NOT NULL,
  `viven_juntos` int(3) NOT NULL,
  `direccion` varchar(60) NOT NULL,
  `email` text NOT NULL,
  `imagen_dni` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `enfermedades`
--

CREATE TABLE `enfermedades` (
  `id_enfermedad` int(16) NOT NULL,
  `descripcion` varchar(50) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarios`
--

CREATE TABLE `horarios` (
  `id_horarios` int(16) NOT NULL,
  `horario` time(6) NOT NULL,
  `id_turno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `horarios`
--

INSERT INTO `horarios` (`id_horarios`, `horario`, `id_turno`) VALUES
(9, '13:00:00.000000', 9),
(10, '11:00:00.000000', 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `instructor`
--

CREATE TABLE `instructor` (
  `id_instructor` int(16) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `id_horarios` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `instructor`
--

INSERT INTO `instructor` (`id_instructor`, `nombre`, `apellido`, `id_horarios`) VALUES
(5, 'Juan', 'Perez', 9),
(6, 'Ignacio', 'Borges', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turno`
--

CREATE TABLE `turno` (
  `id` int(11) NOT NULL,
  `nombre_turno` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `turno`
--

INSERT INTO `turno` (`id`, `nombre_turno`) VALUES
(8, 'Diurno'),
(9, 'Tarde');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubic_localidad`
--

CREATE TABLE `ubic_localidad` (
  `id_localidad` int(11) NOT NULL,
  `nombre_localidad` varchar(50) NOT NULL,
  `id_provincia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ubic_localidad`
--

INSERT INTO `ubic_localidad` (`id_localidad`, `nombre_localidad`, `id_provincia`) VALUES
(2, 'San Fernando', 8),
(3, 'Palermo', 7),
(4, 'Colegiales', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubic_prov`
--

CREATE TABLE `ubic_prov` (
  `id_provincia` int(11) NOT NULL,
  `nombre_provincia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ubic_prov`
--

INSERT INTO `ubic_prov` (`id_provincia`, `nombre_provincia`) VALUES
(7, 'Capital Federal'),
(8, 'Gran Buenos Aires');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `usr_id` int(11) NOT NULL,
  `usr_nombre` varchar(30) NOT NULL,
  `usr_pasword` varchar(10) NOT NULL,
  `usr_email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`usr_id`, `usr_nombre`, `usr_pasword`, `usr_email`) VALUES
(1, 'root', 'root', 'root@gmail.com'),
(2, 'Roxsaly', '123456', 'roxsy30@gmail.com');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `actividad_deportiva`
--
ALTER TABLE `actividad_deportiva`
  ADD PRIMARY KEY (`id_actividad`),
  ADD KEY `id_instructor` (`id_instructor`);

--
-- Indices de la tabla `alumno_enfermedad`
--
ALTER TABLE `alumno_enfermedad`
  ADD PRIMARY KEY (`id_alumno`,`id_enfermedad`),
  ADD KEY `alumno_enfermedad_ibfk_2` (`id_enfermedad`);

--
-- Indices de la tabla `datos_alumno`
--
ALTER TABLE `datos_alumno`
  ADD PRIMARY KEY (`id_alumno`),
  ADD KEY `id_provincia` (`id_provincia`,`id_localidad`),
  ADD KEY `id_localidad` (`id_localidad`),
  ADD KEY `id_actividad` (`id_actividad`,`id_instructor`,`id_horario`),
  ADD KEY `id_instructor` (`id_instructor`),
  ADD KEY `id_horario` (`id_horario`);

--
-- Indices de la tabla `datos_responsable`
--
ALTER TABLE `datos_responsable`
  ADD PRIMARY KEY (`id_responsable`),
  ADD KEY `id_alumno` (`id_alumno`);

--
-- Indices de la tabla `enfermedades`
--
ALTER TABLE `enfermedades`
  ADD PRIMARY KEY (`id_enfermedad`);

--
-- Indices de la tabla `horarios`
--
ALTER TABLE `horarios`
  ADD PRIMARY KEY (`id_horarios`),
  ADD KEY `id_turno` (`id_turno`);

--
-- Indices de la tabla `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`id_instructor`),
  ADD KEY `id_horarios` (`id_horarios`);

--
-- Indices de la tabla `turno`
--
ALTER TABLE `turno`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ubic_localidad`
--
ALTER TABLE `ubic_localidad`
  ADD PRIMARY KEY (`id_localidad`),
  ADD KEY `id_provincia` (`id_provincia`);

--
-- Indices de la tabla `ubic_prov`
--
ALTER TABLE `ubic_prov`
  ADD PRIMARY KEY (`id_provincia`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`usr_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `actividad_deportiva`
--
ALTER TABLE `actividad_deportiva`
  MODIFY `id_actividad` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `datos_alumno`
--
ALTER TABLE `datos_alumno`
  MODIFY `id_alumno` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `datos_responsable`
--
ALTER TABLE `datos_responsable`
  MODIFY `id_responsable` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `enfermedades`
--
ALTER TABLE `enfermedades`
  MODIFY `id_enfermedad` int(16) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `horarios`
--
ALTER TABLE `horarios`
  MODIFY `id_horarios` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `instructor`
--
ALTER TABLE `instructor`
  MODIFY `id_instructor` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `turno`
--
ALTER TABLE `turno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `ubic_localidad`
--
ALTER TABLE `ubic_localidad`
  MODIFY `id_localidad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `ubic_prov`
--
ALTER TABLE `ubic_prov`
  MODIFY `id_provincia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `usr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `actividad_deportiva`
--
ALTER TABLE `actividad_deportiva`
  ADD CONSTRAINT `actividad_deportiva_ibfk_1` FOREIGN KEY (`id_instructor`) REFERENCES `instructor` (`id_instructor`);

--
-- Filtros para la tabla `alumno_enfermedad`
--
ALTER TABLE `alumno_enfermedad`
  ADD CONSTRAINT `alumno_enfermedad_ibfk_1` FOREIGN KEY (`id_alumno`) REFERENCES `datos_alumno` (`id_alumno`),
  ADD CONSTRAINT `alumno_enfermedad_ibfk_2` FOREIGN KEY (`id_enfermedad`) REFERENCES `enfermedades` (`id_enfermedad`);

--
-- Filtros para la tabla `datos_alumno`
--
ALTER TABLE `datos_alumno`
  ADD CONSTRAINT `datos_alumno_ibfk_1` FOREIGN KEY (`id_alumno`) REFERENCES `datos_responsable` (`id_alumno`),
  ADD CONSTRAINT `datos_alumno_ibfk_2` FOREIGN KEY (`id_localidad`) REFERENCES `ubic_localidad` (`id_localidad`),
  ADD CONSTRAINT `datos_alumno_ibfk_3` FOREIGN KEY (`id_provincia`) REFERENCES `ubic_prov` (`id_provincia`),
  ADD CONSTRAINT `datos_alumno_ibfk_4` FOREIGN KEY (`id_actividad`) REFERENCES `actividad_deportiva` (`id_actividad`),
  ADD CONSTRAINT `datos_alumno_ibfk_5` FOREIGN KEY (`id_instructor`) REFERENCES `instructor` (`id_instructor`),
  ADD CONSTRAINT `datos_alumno_ibfk_6` FOREIGN KEY (`id_horario`) REFERENCES `horarios` (`id_horarios`);

--
-- Filtros para la tabla `horarios`
--
ALTER TABLE `horarios`
  ADD CONSTRAINT `horarios_ibfk_1` FOREIGN KEY (`id_turno`) REFERENCES `turno` (`id`);

--
-- Filtros para la tabla `instructor`
--
ALTER TABLE `instructor`
  ADD CONSTRAINT `instructor_ibfk_1` FOREIGN KEY (`id_horarios`) REFERENCES `horarios` (`id_horarios`);

--
-- Filtros para la tabla `ubic_localidad`
--
ALTER TABLE `ubic_localidad`
  ADD CONSTRAINT `ubic_localidad_ibfk_1` FOREIGN KEY (`id_provincia`) REFERENCES `ubic_prov` (`id_provincia`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

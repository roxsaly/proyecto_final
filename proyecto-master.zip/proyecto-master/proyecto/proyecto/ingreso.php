<!DOCTYPE html>
<?php
	require('conexion.php');
?>


<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Polideportivo los coquitos</title>

</head>
<body>

	<header>
	     <?php
		include("header.php");
		?> 
	</header>

<!-- menu de navegación -->


  

<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e3f2fd";>
  
  
    
  
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Tabla Básica
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="disciplina_deportiva.php">Disciplina Deportiva</a>
          <a class="dropdown-item" href="horarios.php">Horario</a>
          <a class="dropdown-item" href="instructores.php">Instructor</a>
          <a class="dropdown-item" href="provincia.php">Provincia</a>
          <a class="dropdown-item" href="localidad.php">Localidad</a>
                          
        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Ficha de Inscripción
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Alumnos Activos</a>
          <a class="dropdown-item" href="#">Alumnos Inactivos</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Constancia de Estudio</a>
        </div>
      </li>

            <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Actividades
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Eventos Próximos</a>
      </li>

            <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Estadística
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Reportes</a>
        </div>
      </li>

     </ul>

  </div>

</nav>



</div>

	<article>
		<br>
		<br>

	
				<h4 class="card-title">Bienvenido Root</h4>

   <!--      para salir de sesion,falta probar seguridad -->

				<a href="logout.php">Actividades></a>
	
			

	</article>

	<footer>
		<?php
		include("footer.php");
		?>
	</footer>


	
</body>
</html>
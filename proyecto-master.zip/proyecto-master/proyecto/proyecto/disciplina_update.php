<?php
include "conexion.php";
if(isset($_POST['update'])){
				$id_actividad = intval($_POST['id_actividad']);
				$descripcion  = mysqli_real_escape_string($mysqli,(strip_tags($_POST['descripcion'], ENT_QUOTES)));
				$id_instructor = mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_instructor'], ENT_QUOTES)));
				
				
				$update = mysqli_query($mysqli, "UPDATE instructor 
											   SET descripcion='$descripcion', 
											   	   id_instructor ='$id_instructor ', 
											   WHERE id_actividad='$id_actividad'") or die(mysqli_error());
				if($update){
					echo "<script>alert('Los datos han sido actualizados!'); window.location = 'disciplina_deportiva.php'</script>";
				}else{
					echo "<script>alert('Error, no se pudo actualizar los datos'); window.location = 'disciplina_deportiva.php'</script>";
				}
			}
  ?>
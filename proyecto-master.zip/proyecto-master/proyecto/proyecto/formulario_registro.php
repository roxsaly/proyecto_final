<?php include "conexion.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>

<!-- Script para formulario2 cuando el alumno es menor de edad -->
<script type="text/javascript">


	function capturar() {
	
	var fecha = document.getElementById("fecha_nacimiento").value;

    var fechaNace = new Date(fecha);
    var fechaActual = new Date()

    var mes = fechaActual.getMonth();
    var dia = fechaActual.getDate();
    var año = fechaActual.getFullYear();

    fechaActual.setDate(dia);
    fechaActual.setMonth(mes);
    fechaActual.setFullYear(año);

    edad = Math.floor(((fechaActual - fechaNace) / (1000 * 60 * 60 * 24) / 365));
   
   if (edad < 18) {

   	alert("Es menor de edad, favor llenar el siguiente Formulario con los datos de Padre, Madre o Responsable Legal");

   	$(document).ready(function(){


  		// $("#formulario2").modal(); ver script para activar modal formulario2
  
});

   }

    document.getElementById("edad").value =  edad ;//ver campo edad menor de 18, investigar
}
</script>

<body class="bg-light">
	<div class="Container">
		<h1><div class="py-5 text-center">Datos Personales</div></h1>
	</div>

<!-- registro en la Base de Datos -->
 <?php
			if(isset($_POST['input'])){
				$nombres	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['nombres'], ENT_QUOTES)));
				$apellidos  = mysqli_real_escape_string($mysqli,(strip_tags($_POST['apellidos'], ENT_QUOTES)));
				$dni 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['dni'], ENT_QUOTES)));
				$fecha_nacimiento 	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['fecha_nacimiento'], ENT_QUOTES)));
				$sexo 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['sexo'], ENT_QUOTES)));
				$contacto_casa 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['contacto_casa'], ENT_QUOTES)));
				$contacto_celular 	= mysqli_real_escape_string($mysqli,(strip_tags($_POST['contacto_celular'], ENT_QUOTES)));
				$email 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['email'], ENT_QUOTES)));
				$peso 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['peso'], ENT_QUOTES)));
				$estatura 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['estatura'], ENT_QUOTES)));
				$imagen_alumno= mysqli_real_escape_string($mysqli,(strip_tags($_POST['imagen_alumno'], ENT_QUOTES)));
				$imagen_dni_alumno= mysqli_real_escape_string($mysqli,(strip_tags($_POST['imagen_dni_alumno'], ENT_QUOTES)));
				$id_provincia = mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_provincia'], ENT_QUOTES)));
				$id_localidad = mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_localidad'], ENT_QUOTES)));
				$calle 		= mysqli_real_escape_string($mysqli,(strip_tags($_POST['calle'], ENT_QUOTES)));
				$numero_calle = mysqli_real_escape_string($mysqli,(strip_tags($_POST['numero_calle'], ENT_QUOTES)));
				$departamento = mysqli_real_escape_string($mysqli,(strip_tags($_POST['departamento'], ENT_QUOTES)));
				$cobertura_medica = mysqli_real_escape_string($mysqli,(strip_tags($_POST['cobertura_medica'], ENT_QUOTES)));
				$num_afiliado = mysqli_real_escape_string($mysqli,(strip_tags($_POST['num_afiliado'], ENT_QUOTES)));
				$pers_contacto= mysqli_real_escape_string($mysqli,(strip_tags($_POST['pers_contacto'], ENT_QUOTES)));
				$tlf_pers_contacto= mysqli_real_escape_string($mysqli,(strip_tags($_POST['tlf_pers_contacto'], ENT_QUOTES)));
				$id_actividad = mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_actividad'], ENT_QUOTES)));
				$id_instructor= mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_instructor'], ENT_QUOTES)));
				$id_horario = mysqli_real_escape_string($mysqli,(strip_tags($_POST['id_horario'], ENT_QUOTES)));


				$insert = mysqli_query($mysqli, "INSERT INTO datos_alumno (id_alumno, nombres, apellidos, dni, fecha_nacimiento, sexo, contacto_casa, contacto_celular, email, peso, estatura, imagen_alumno, imagen_dni_alumno, id_provincia, id_localidad, calle, numero_calle, departamento, cobertura_medica, num_afiliado, pers_contacto, tlf_pers_contacto, id_actividad, id_instructor, id_horario)
											VALUES(NULL,'$nombres', '$apellidos', '$dni', '$fecha_nacimiento', '$sexo', '$contacto_casa', '$contacto_celular', '$email', '$peso', '$estatura', '$imagen_alumno', '$imagen_dni_alumno', '$id_provincia', '$id_localidad', '$calle', '$numero_calle', '$departamento', '$cobertura_medica', '$num_afiliado', '$pers_contacto', '$tlf_pers_contacto', '$id_actividad', '$id_instructor', '$id_horario')") or die(mysqli_error());
						if($insert){
							echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Bien hecho, los datos han sido agregados correctamente.</div>';
						}else{
							echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Error, no se pudo registrar los datos.</div>';
						}
				
			}
			?>

<form  name="form1" id="form1" class="form-horizontal row-fluid" action="formulario_registro.php" method="POST" >
		
<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="nombres">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" name="nombres" id="nombres" placeholder="Nombres" >
			<div class="invalid-feedback">
				Valide el nombre es requerido
			</div>
		</div>		

		<div class="form-group col-md-4">
			<label for="apellidos">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" name="apellidos" id="apellidos" placeholder="Apellidos">
			<div class="invalid-feedback">
				Valide el apellido es requerido
			</div>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>

			<div class="form-group col-md-4">
      		<label for="dni">
 			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>	     			
      		</label>
      		<input type="number" class="form-control" name="dni" id="dni" placeholder="DNI">
      		<div class="invalid-feedback">
      			Valide el DNI es requerido
      		</div>
    	</div>

    <div class="form-group col-md-3">
      
      		<label for="fecha_nacimiento">Fecha de nacimiento</label>
     		 <input type="date" class="form-control" name="fecha_nacimiento" id="fecha_nacimiento" placeholder="Fecha de nacimiento" onchange= "capturar();">
      		<div class="invalid-feedback">
      			Valide la Fecha de nacimiento es requerido
   			</div>
   		</div>

   <div class="form-group col-md-1">
      
      		<label for="edad"></label>
      		<input type="number" class="form-control" id="edad" placeholder="Edad" readonly>
    	</div>

    <div class="form-group col-md-2"></div>
</div>

<div class="row">

	<div class="form-group col-md-2"></div>

		<div class="form-group col-md-4">
		 <legend class="col-form-label col-sm-2">Sexo</legend>
      		
          	<input class="form-check-input col-md-1" type="radio" name="sexo" id="sexo" value="M" checked>
          	<label class="form-check-label col-md-4" for="gridRadios1">Masculino</label>
          	<input class="form-check-input col-md-1" type="radio" name="sexo" id="sexo" value="F">
         	<label class="form-check-label col-md-6" for="gridRadios2">Femenino</label>
		</div>

		<div class="form-group col-md-4">
			<label for="contacto_casa">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" name="contacto_casa" id="contacto_casa" placeholder="Telefono de Contacto Casa">
		</div>

	<div class="form-group col-md-2"></div>
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="email">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="email" class="form-control" name="email" id="email" placeholder="Correo electrónico" >
		</div>		

		<div class="form-group col-md-4">
			<label for="contacto_celular">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" name="contacto_celular" id="contacto_celular" placeholder="Telefono de Contacto Celular">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="peso">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="number" class="form-control" name="peso" id="peso" placeholder="Peso" >
		</div>		

		<div class="form-group col-md-4">
			<label for="estatura">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="number" class="form-control" name="estatura" id="estatura" placeholder="Estatura">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<select class="custom-select" name="id_provincia" id="id_provincia">
  			<option selected>Provincia</option>
  			<option value="7">CABA</option>
 			<option value="8">Provincia de Buenos Aires</option>
			</select>
			<div class="invalid-feedback">
      			Valide la Provincia es requerido
   			</div>
		</div>

		<div class="form-group col-md-4">
			<select class="custom-select" name="id_localidad" id="id_localidad">
  			<option selected>Localidad</option>
  			<option value="2">San Fernando</option>
 			<option value="3">Palermo</option>
 			<option value="4">Colegiales</option>
			</select>
			<div class="invalid-feedback">
      			Valide la Localidad es requerido
   			</div>
   		</div>

   	<!-- 	FALTA ASOCIAR ESTO A LA BD -->
		
	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="calle">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" name="calle" id="calle" placeholder="Calle/Avenida" >
			<div class="invalid-feedback">
      			Valide la Calle/Avenida es requerido
   			</div>
		</div>		

		<div class="form-group col-md-2">
			<label for="numero_calle">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="number" class="form-control" name="numero_calle" id="numero_calle" placeholder="Número">
		</div>

		<div class="form-group col-md-2">
			<label for="departamento">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="number" class="form-control" name="departamento" id="departamento" placeholder="Departamento">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="cobertura_medica">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" name="cobertura_medica" id="cobertura_medica" placeholder="Cobertura Médica" >
		</div>		

		<div class="form-group col-md-4">
			<label for="num_afiliado">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" name="num_afiliado" id="num_afiliado" placeholder="Número de Afiliado">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

<!-- falta crear en la tabla de Base de Datos, pendiente por incluir
 --><!-- 	<div class="form-group col-md-8">
			<label for="ContactoEmergencia">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" name="tlf_pers_contacto" id="tlf_pers_contacto" placeholder="Telefono de Cobertura en caso de Emergencia">
		</div> -->	

	<div class="form-group col-md-2"></div>
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

	<div class="form-group col-md-4">
			<label for="pers_contacto">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" name="pers_contacto" id="pers_contacto" placeholder="En caso de Emergencia contactar a:">
		</div>		

	<div class="form-group col-md-4">
			<label for="tlf_pers_contacto">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" name="tlf_pers_contacto" id="tlf_pers_contacto" placeholder="Telefono de Contacto">
		</div>		

	<div class="form-group col-md-2"></div>
</div>

<div class="text-center"><h4>Antecedentes Médicos</h4></div>

<div class="text-center"><h5>Marca el recuadro si presento algunas de estas enfermedades en los últimos dos años</h5></div>


<!-- falta crear en la tabla de Base de Datos, pendiente por incluir-->
<!-- <div class="row">

	<div class="form-group col-md-2"></div>	

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck1">
  		<label class="custom-control-label" for="customCheck1">Fracturas</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck2">
  		<label class="custom-control-label" for="customCheck2">Enfermedad Muscular</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck3">
  		<label class="custom-control-label" for="customCheck3">Neumonía</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck4">
  		<label class="custom-control-label" for="customCheck4">Sarampión/Rubeola</label>
		</div>
 -->
	<!-- <div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck5">
  		<label class="custom-control-label" for="customCheck5">Esguinces</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck6">
  		<label class="custom-control-label" for="customCheck6">Asma</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck7">
  		<label class="custom-control-label" for="customCheck7">Varicela</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck8">
  		<label class="custom-control-label" for="customCheck8">Hepatitis</label>
		</div>

	<div class="form-group col-md-2"></div>	
</div> -->

<!-- <div class="row">

	<div class="form-group col-md-2"></div>	

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck9">
  		<label class="custom-control-label" for="customCheck9">Hernias</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck10">
  		<label class="custom-control-label" for="customCheck10">Hipertensión Arterial</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck11">
  		<label class="custom-control-label" for="customCheck11">Soplos Cardíacos</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck12">
  		<label class="custom-control-label" for="customCheck12">Aritmias Cardiacas</label>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck13">
  		<label class="custom-control-label" for="customCheck13">Perdida de conocimiento</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck14">
  		<label class="custom-control-label" for="customCheck14">Convulsiones</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck15">
  		<label class="custom-control-label" for="customCheck15">Anemia</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck16">
  		<label class="custom-control-label" for="customCheck16">Intervención Quirúrgica	</label>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

		<div class="text-center"><h5>Actividad Deportiva</h5></div>
 -->
		<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<select class="custom-select" name="id_actividad" id="id_actividad">
  			<option selected>Disciplina Deportiva</option>
  			<option value="3">Futbol</option>
 			<option value="4">Voleyball</option>
 			<option value="5">Baloncesto</option>
			</select>
			<div class="invalid-feedback">
      			Valide la Disciplina Deportiva es requerido
   			</div>
		</div>

		<div class="form-group col-md-4">
			<select class="custom-select" name="id_horario" id="id_horario">
  			<option selected>Horario</option>
  			<option value="9">14:00 a 15:00</option>
 			<option value="10">16:00 a 17:00</option>
			</select>
			<div class="invalid-feedback">
      			Valide el horario es requerido
   			</div>
   		</div>

<!-- ver donde diseñar el campo, incluido en la DB -->
   	<div class="form-group col-md-2"></div>
   			<select class="custom-select" name="id_instructor" id="id_instructor">
  			<option selected>Instructor</option>
  			<option value="5">Juan</option>
 			<option value="6">Ignacio</option>
			</select>
			<div class="invalid-feedback">
      			Valide el Instructor es requerido
   			</div>	
   	</div>	

<!-- validar esta información con la BD, investigar como relacionarla -->

<!-- ajustar texto, visualizar carga de archivo y diseño del formulario -->
<div class="text-center"><h5>PARA INSCRIBIRSE ES IMPRESCINDIBLE ADJUNTAR APTO MEDICO, DNI DEL ALUMNO, MADRE/ PADRE Y RESPONSABLE (SI CORRESPONDE)</h5></div>



		<div class="form-group col-md-4">
			<div class="col-md-4 mb-3">
			  <input type="text" class="form-control" name="imagen_dni_alumno" id="imagen_dni_alumno" >
			  
			</div>
		</div>
			
			<!-- campo no registrado en esta Base de Datos -->  
		<!-- <div class="custom-file">
			<div class="col-md-4 mb-3">
			  <input type="file" class="custom-file-input" id="customFileLang2" lang="es">
			  <label class="custom-file-label" for="customFileLang">Seleccionar Archivo DNI madre/padre o Responsable</label>
			</div>
		</div> -->

			<!-- campo no registrado en esta Base de Datos --> 
		<!-- <div class="custom-file">
			<div class="col-md-4 mb-3">
			  <input type="file" class="custom-file-input" id="customFileLang3" lang="es">
			  <label class="custom-file-label" for="customFileLang">Seleccionar Archivo Apto médico (vigencia de 6 meses)</label>
			</div>
		</div> -->

		<div class="form-group col-md-4">
			<div class="col-md-4 mb-3">
			 <input type="text" class="form-control" name="imagen_alumno" id="imagen_alumno">
			 
			 </div>
		</div>


<div class="row">

<div class="form-group col-md-2"></div> 


	<div class="form-group col-md-8" align="text-center">Por la presente cedo los derechos y autorizo al Polideportivo Los Coquitos para utilizar el material gráfico, fotográfico, fílmico, audiovisual, o de cualquier otra clase, que fuera producido en el marco de actividades organizadas por éste o desarrolladas bajo su órbita teniendo la finalidad de promover el derecho al deporte. Esta autorización comprende cualquier forma y medio de difusión, distribución, edición, reproducción, publicación, adaptación y/o impresión, por cualquier medio y formato, por sí o por intermedio de terceros, renunciando expresa e incondicionalmente a reclamar compensación alguna al respecto. Declaro bajo juramento que el autorizado no posee patología ni impedimento alguno para desarrollar la presente práctica deportiva encontrándose sin impedimento físico o deficiencia que pudiera provocar lesiones y cualquier otro daño corporal como consecuencia de la participación de la presente actividad. Asimismo, se deja expresa constancia que libero de toda responsabilidad al Polideportivo Los Coquitos por los eventuales daños y/o perjuicios que pudieran derivarse de la inscripción y participación del autorizado en las presentes actividades. La liberación de responsabilidad aludida alcanza a todo daño que pudiera eventualmente sufrir el autorizado y/o bienes como consecuencia de la participación en el programa mencionado, incluso caso fortuito o fuerza mayor. En virtud de la liberación de responsabilidad efectuada precedentemente, renuncio en este acto a reclamar indemnización alguna al Polideportivo Los Coquitos por los eventuales daños que pudiera sufrir.</div>

<div class="form-group col-md-2"></div>

</div>
    <div class="form-check">


      <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
      <label class="form-check-label" for="invalidCheck">
        He leído las normas y acepto las condiciones
      </label>
      <div class="invalid-feedback">
        Favor leer las normas y condiciones para realizar la inscripción
      </div>
    </div>
  <div class="text-center">
  <button class="btn btn-primary" type="submit">Enviar Formulario</button>
</div>
</form>



</body>
</html>
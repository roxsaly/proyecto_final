<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Polideportivo los coquitos</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link href="https://fonts.googleapis.com/css?family=Permanent+Marker&display=swap" rel="stylesheet">
</head>
<body>

	<header>
	<div class="enlaces">
		<nav> 
			<a href="index.php">Home></a>
			<a href="actividades.php">Actividades></a>
			<a href="contacto.php">Contacto</a>
		</nav>
	</div>

	<br>

	<div class="header">

		<blockquote class="blockquote text-center">
  <h1><p class="mb-0">POLIDEPORTIVO LOS COQUITOS</p></h1>
  
</blockquote>

			<!-- <h1>POLIDEPORTIVO LOS COQUITOS</h1> -->
			
		</div>

	</header>

</body>
</html>
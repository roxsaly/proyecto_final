<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<script type="text/javascript">


	function capturar() {
	
	var fecha = document.getElementById("fNacimiento").value;

    var fechaNace = new Date(fecha);
    var fechaActual = new Date()

    var mes = fechaActual.getMonth();
    var dia = fechaActual.getDate();
    var año = fechaActual.getFullYear();

    fechaActual.setDate(dia);
    fechaActual.setMonth(mes);
    fechaActual.setFullYear(año);

    edad = Math.floor(((fechaActual - fechaNace) / (1000 * 60 * 60 * 24) / 365));
   
   if (edad < 18) {

   	alert("Es menor de edad, favor llenar el siguiente Formulario con los datos de Padre, Madre o Responsable Legal");

   	$(document).ready(function(){
  		// $("#formulario2").modal(); ver script para activar modal formulario2
  
});

   }

    document.getElementById("edad").value =  edad ;//ver campo edad menor de 18, investigar
}
</script>


<!-- <div class="modal" id="formulario2" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Datos de Madre Padre o Responsable</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<div class="container-fluid">
   		 <div class="row">
			<div class="col-md-6 ml-auto">.col-md-6 .ml-auto</div>
    		</div>
    	</div>
    </div>

        <p>Modal body text goes here.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
 -->


<body class="bg-light">
	<div class="Container">
		<h1><div class="py-5 text-center">Datos Personales</div></h1>
	</div>
<form class="needs-validation" novalidate>
		
<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="Nombres">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" id="Nombres" placeholder="Nombres" >
			<div class="invalid-feedback">
				Valide el nombre es requerido
			</div>
		</div>		

		<div class="form-group col-md-4">
			<label for="Apellidos">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" id="apellido" placeholder="Apellidos">
			<div class="invalid-feedback">
				Valide el apellido es requerido
			</div>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>

			<div class="form-group col-md-4">
      		<label for="Document">
 			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>	     			
      		</label>
      		<input type="number" class="form-control" id="dni" placeholder="DNI">
      		<div class="invalid-feedback">
      			Valide el DNI es requerido
      		</div>
    	</div>

    <div class="form-group col-md-3">
      
      		<label for="date">Fecha de nacimiento</label>
     		 <input type="date" class="form-control" id="fNacimiento" placeholder="Fecha de nacimiento" onchange= "capturar();">
      		<div class="invalid-feedback">
      			Valide la Fecha de nacimiento es requerido
   			</div>
   		</div>

   <div class="form-group col-md-1">
      
      		<label for="Edad"></label>
      		<input type="number" class="form-control" id="edad" placeholder="Edad" readonly>
    	</div>

    <div class="form-group col-md-2"></div>
</div>

<div class="row">

	<div class="form-group col-md-2"></div>

		<div class="form-group col-md-4">
		 <legend class="col-form-label col-sm-2">Sexo</legend>
      		
          	<input class="form-check-input col-md-1" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
          	<label class="form-check-label col-md-4" for="gridRadios1">Masculino</label>
          	<input class="form-check-input col-md-1" type="radio" name="gridRadios" id="gridRadios2" value="option2">
         	<label class="form-check-label col-md-6" for="gridRadios2">Femenino</label>
		</div>

		<div class="form-group col-md-4">
			<label for="Telefono">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" id="telefono1" placeholder="Telefono de Contacto Casa">
		</div>

	<div class="form-group col-md-2"></div>
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="inputEmail3">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="email" class="form-control" id="inputEmail3" placeholder="Correo electrónico" >
		</div>		

		<div class="form-group col-md-4">
			<label for="Telefono2">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" id="Telefono2" placeholder="Telefono de Contacto Celular">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="Peso">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="number" class="form-control" id="Peso" placeholder="Peso" >
		</div>		

		<div class="form-group col-md-4">
			<label for="Estatura">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="number" class="form-control" id="Estatura" placeholder="Estatura">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<select class="custom-select">
  			<option selected>Provincia</option>
  			<option value="1">CABA</option>
 			<option value="2">Provincia de Buenos Aires</option>
			</select>
			<div class="invalid-feedback">
      			Valide la Provincia es requerido
   			</div>
		</div>

		<div class="form-group col-md-4">
			<select class="custom-select">
  			<option selected>Localidad</option>
  			<option value="1">Colegiales</option>
 			<option value="2">Chacarita</option>
 			<option value="3">Palermo</option>
			</select>
			<div class="invalid-feedback">
      			Valide la Localidad es requerido
   			</div>
   		</div>

   	<!-- 	FALTA ASOCIAR ESTO A LA BD -->
		
	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="Direccion">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" id="Direccion" placeholder="Calle/Avenida" >
			<div class="invalid-feedback">
      			Valide la Calle/Avenida es requerido
   			</div>
		</div>		

		<div class="form-group col-md-2">
			<label for="Numerodireccion">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="number" class="form-control" id="Numerodireccion" placeholder="Número">
		</div>

		<div class="form-group col-md-2">
			<label for="Numerodireccion2">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="number" class="form-control" id="Numerodireccion2" placeholder="Departamento">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<label for="Cobertura">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" id="Cobertura" placeholder="Cobertura Médica" >
		</div>		

		<div class="form-group col-md-4">
			<label for="Afiliado">
			<font style="vertical-align: ">
			<font style="vertical-align: inherit;"></font>
			</font>		
			</label>
			<input type="text" class="form-control" id="Afiliado" placeholder="Número de Afiliado">
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

	<div class="form-group col-md-8">
			<label for="ContactoEmergencia">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" id="ContactoEmergencia" placeholder="Telefono de Cobertura en caso de Emergencia">
		</div>		
	<div class="form-group col-md-2"></div>
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

	<div class="form-group col-md-4">
			<label for="ContactoEmergencia2">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" id="ContactoEmergencia2" placeholder="En caso de Emergencia contactar a:">
		</div>		

	<div class="form-group col-md-4">
			<label for="ContactoEmergencia3">
			<font style="vertical-align: inherit;">
			<font style="vertical-align: inherit;"></font>
			</font>
			</label>
			<input type="text" class="form-control" id="ContactoEmergencia3" placeholder="Telefono de Contacto">
		</div>		

	<div class="form-group col-md-2"></div>
</div>

<div class="text-center"><h4>Antecedentes Médicos</h4></div>

<div class="text-center"><h5>Marca el recuadro si presento algunas de estas enfermedades en los últimos dos años</h5></div>

<div class="row">

	<div class="form-group col-md-2"></div>	

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck1">
  		<label class="custom-control-label" for="customCheck1">Fracturas</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck2">
  		<label class="custom-control-label" for="customCheck2">Enfermedad Muscular</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck3">
  		<label class="custom-control-label" for="customCheck3">Neumonía</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck4">
  		<label class="custom-control-label" for="customCheck4">Sarampión/Rubeola</label>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck5">
  		<label class="custom-control-label" for="customCheck5">Esguinces</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck6">
  		<label class="custom-control-label" for="customCheck6">Asma</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck7">
  		<label class="custom-control-label" for="customCheck7">Varicela</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck8">
  		<label class="custom-control-label" for="customCheck8">Hepatitis</label>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck9">
  		<label class="custom-control-label" for="customCheck9">Hernias</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck10">
  		<label class="custom-control-label" for="customCheck10">Hipertensión Arterial</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck11">
  		<label class="custom-control-label" for="customCheck11">Soplos Cardíacos</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck12">
  		<label class="custom-control-label" for="customCheck12">Aritmias Cardiacas</label>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

<div class="row">

	<div class="form-group col-md-2"></div>	

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck13">
  		<label class="custom-control-label" for="customCheck13">Perdida de conocimiento</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck14">
  		<label class="custom-control-label" for="customCheck14">Convulsiones</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck15">
  		<label class="custom-control-label" for="customCheck15">Anemia</label>
		</div>

		<div class="form-group col-md-2 custom-control custom-checkbox">
  		<input type="checkbox" class="custom-control-input" id="customCheck16">
  		<label class="custom-control-label" for="customCheck16">Intervención Quirúrgica	</label>
		</div>

	<div class="form-group col-md-2"></div>	
</div>

		<div class="text-center"><h5>Actividad Deportiva</h5></div>

		<div class="row">

	<div class="form-group col-md-2"></div>	
	
		<div class="form-group col-md-4">
			<select class="custom-select">
  			<option selected>Disciplina Deportiva</option>
  			<option value="1">Futbol</option>
 			<option value="2">Tenis</option>
			</select>
			<div class="invalid-feedback">
      			Valide la Disciplina Deportiva es requerido
   			</div>
		</div>

		<div class="form-group col-md-4">
			<select class="custom-select">
  			<option selected>Horario</option>
  			<option value="1">14:00 a 15:00</option>
 			<option value="2">16:00 a 17:00</option>
 			<option value="3">17:00 a 18:00</option>
			</select>
			<div class="invalid-feedback">
      			Valide el horario es requerido
   			</div>
   		</div>

   	<div class="form-group col-md-2"></div>	
   	</div>	

<!-- validar esta información con la BD, investigar como relacionarla -->

<!-- ajustar texto, visualizar carga de archivo y diseño del formulario -->
<div class="text-center"><h5>PARA INSCRIBIRSE ES IMPRESCINDIBLE ADJUNTAR APTO MEDICO, DNI DEL ALUMNO, MADRE/ PADRE Y RESPONSABLE (SI CORRESPONDE)</h5></div>



		<div class="custom-file">
			<div class="col-md-4 mb-3">
			  <input type="file" class="custom-file-input" id="customFileLang1" lang="es">
			  <label class="custom-file-label" for="customFileLang">Seleccionar Archivo DNI alumno</label>
			</div>
		</div>
			  
		<div class="custom-file">
			<div class="col-md-4 mb-3">
			  <input type="file" class="custom-file-input" id="customFileLang2" lang="es">
			  <label class="custom-file-label" for="customFileLang">Seleccionar Archivo DNI madre/padre o Responsable</label>
			</div>
		</div>

		<div class="custom-file">
			<div class="col-md-4 mb-3">
			  <input type="file" class="custom-file-input" id="customFileLang3" lang="es">
			  <label class="custom-file-label" for="customFileLang">Seleccionar Archivo Apto médico (vigencia de 6 meses)</label>
			</div>
		</div>

		<div class="custom-file">
			<div class="col-md-4 mb-3">
			 <input type="file" class="custom-file-input" id="customFileLang3" lang="es">
			  <label class="custom-file-label" for="customFileLang">Seleccionar Archivo Foto alumno (formato jpg, png o pdf)</label>
			 </div>
		</div>

    
	<p>Por la presente cedo los derechos y autorizo al Polideportivo Los Coquitos para utilizar el material gráfico, fotográfico, fílmico, audiovisual, o de cualquier otra clase, que fuera producido en el marco de actividades organizadas por éste o desarrolladas bajo su órbita teniendo la finalidad de promover el derecho al deporte. Esta autorización comprende cualquier forma y medio de difusión, distribución, edición, reproducción, publicación, adaptación y/o impresión, por cualquier medio y formato, por sí o por intermedio de terceros, renunciando expresa e incondicionalmente a reclamar compensación alguna al respecto. Declaro bajo juramento que el autorizado no posee patología ni impedimento alguno para desarrollar la presente práctica deportiva encontrándose sin impedimento físico o deficiencia que pudiera provocar lesiones y cualquier otro daño corporal como consecuencia de la participación de la presente actividad. Asimismo, se deja expresa constancia que libero de toda responsabilidad al Polideportivo Los Coquitos por los eventuales daños y/o perjuicios que pudieran derivarse de la inscripción y participación del autorizado en las presentes actividades. La liberación de responsabilidad aludida alcanza a todo daño que pudiera eventualmente sufrir el autorizado y/o bienes como consecuencia de la participación en el programa mencionado, incluso caso fortuito o fuerza mayor. En virtud de la liberación de responsabilidad efectuada precedentemente, renuncio en este acto a reclamar indemnización alguna al Polideportivo Los Coquitos por los eventuales daños que pudiera sufrir.</p>

    <div class="form-check">


      <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
      <label class="form-check-label" for="invalidCheck">
        He leído las normas y acepto las condiciones
      </label>
      <div class="invalid-feedback">
        Favor leer las normas y condiciones para realizar la inscripción
      </div>
    </div>
  <div class="text-center">
  <button class="btn btn-primary" type="submit">Enviar Formulario</button>
</div>




</body>
</html>
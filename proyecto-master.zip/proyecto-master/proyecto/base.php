<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Polideportivo los coquitos</title>
</head>
<body>

	<header>
		<?php
		include("header.php");
		?>
	</header>

	<article>
		<br>
		<br>

	<div class="row">
      <div class="col-lg-1" >
      </div>

      <div class="col-lg-2" >
       
			<div class="btn-group-vertical"  role="group" aria-label="Grupo de botones vertical">
				<button type="button" class="btn botones">Escuela de iniciación deportiva</button>
				<button type="button" class="btn botones">Disciplinas</button>
				<button type="button" class="btn botones">Inscripción año 2019<img src="img/new.png" width="20%"></button>
			</div>
	
      </div>
      <div class="col-lg-5" >
       
		<div class="card">	
			<div class="card-img-top">
 				 <img src="img\deporte2.png" width="600" class="card-rounded " alt="Disciplinas">
			</div>
		</div>

      </div>
 		<div class="col-lg-3" >
       		<div class="card">	
			<div class="card-body">
				<h4 class="card-title">POLIDEPORTIVOS LOS COQUITOS</h4>
				<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae non repudiandae ea eos architecto amet, cumque sed, quisquam corporis magnam, laudantium maiores obcaecati iusto velit aperiam, vero eveniet placeat. Dolorem!</p>
			</div>
		</div>
      </div>

 	   <div class="col-lg-1"  >
     
      </div>

	</div>

	</article>

	<footer>
		<?php
		include("footer.php");
		?>
	</footer>
	
</body>
</html>